import java.util.Scanner;


public class ApplicationUI {
    public static void main(String[] args) {
        System.out.println(System.getProperty("user.dir"));
        Scanner sc = new Scanner(System.in);
        String exit = "0";
        while(!exit.equals("1")){
            try{
                
                    System.out.println("Welcome to the login page");
                    System.out.println("Please enter your Hospital ID and Password");

                    System.out.println();
                    System.out.print("Username: ");
                    String userName = sc.next().toUpperCase();
                    // String userName = "D001"; // speed up testing purpose

                    System.out.print("Password: ");
                    String password = sc.next();
                    // String password = "Password";

                    LogInManager login = new LogInManager(userName, password);
                    boolean accept = login.authoriseLogin();
                    if (accept) {
                        System.out.println("Welcome");
                        userOption(userName);
                    } else {
                        System.out.println("Login failed.");
                        System.out.println("If you would like to exit. Press 1.");
                        System.out.println("If you would like to try again. press any other key.");
                        exit = sc.next();
                    }
            } catch (Exception e) {
                System.out.println("An error occurred. Please try again.");
            } finally {
                sc.close();
            }
        }
    }

    public static void userOption(String userName) {
        //initialise outside to avoid initialising multiple times
        ScheduleManager scheduleManager = new ScheduleManager();
        AppointmentManager am = new AppointmentManager();

        // Step 2: Set the references in each other
        scheduleManager.setAppointmentManager(am);
        am.setScheduleManager(scheduleManager);

        // Step 3: Now initialize appointments and schedules as needed
        am.initializeAppointments();        // Initialize appointments
        scheduleManager.initialiseSchedule(); // Initialize schedule


        String useString = userName.toUpperCase();

        if (useString.length() == 5){

            //Patient 
            if (useString.startsWith("p") || useString.startsWith("P")){ // [To Remove] Can remove
                MedicalRecordManager mrm = new MedicalRecordManager();
                PatientManager pm = new PatientManager();
                new PatientUI(useString, pm, mrm, scheduleManager, am);
            }
        } else if(useString.length() == 4){
            //Doctor
            if (useString.startsWith("d") || useString.startsWith("D")){
                MedicalRecordManager mrm = new MedicalRecordManager();
                StaffManager sm = new StaffManager();
                new DoctorUI(useString, sm, mrm, am, scheduleManager);
            }
            //Admin
            else if (useString.startsWith("a") || useString.startsWith("A")){
                StaffManager sm = new StaffManager();
                new AdministratorUI(useString, sm, am);
            } 

            //Pharmacist
            else if (useString.startsWith("p") || useString.startsWith("P") || userName.startsWith("PH") || userName.startsWith("pH")){
                 StaffManager sm = new StaffManager();
                 new PharmacistUI(userName, sm);
            } 

        }else {
                System.out.println("Invalid user ID");
        }
    }
}

