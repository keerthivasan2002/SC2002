public interface UserUI {
    void userOption();

}
