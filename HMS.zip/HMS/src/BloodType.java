public enum BloodType{
    O_POSITIVE,
    O_NEGATIVE,
    A_POSITIVE,
    A_NEGATIVE,
    B_POSITIVE,
    B_NEGATIVE,
    AB_POSITIVE,
    AB_NEGATIVE
}