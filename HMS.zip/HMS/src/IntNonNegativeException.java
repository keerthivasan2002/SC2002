public class IntNonNegativeException extends Exception
{
    //construct
    public IntNonNegativeException(){
        super("Integer input is a negative number!! ");
    }

    // public IntNonNegativeException(String meassage){
    //     super(message);
    // }
}