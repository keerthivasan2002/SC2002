public enum AppointmentStatus {
    CONFIRMED,
    CANCELLED,
    COMPLETED,
    REJECTED,
    PENDING,
    APPROVED,
    SCHEDULED
}
