public interface StudentUI extends UserUI {
    void viewProfile();
    void updateInfo();
}



