public enum HospitalRole {
    DOCTOR,
    PATIENT,
    ADMINISTRATOR,
    PHARMACIST,
    STUDENT
}
